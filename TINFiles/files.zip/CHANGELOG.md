# Changelog — TIN (The Interplanetary Network)

All notable changes to this proposal are documented here.

## v0.3 (February 2026) — Simulation & Validation
- Added `simulations/` folder with coverage geometry, link budget, and orbital analysis
- Combined network performance modeling (`CombinedNetworkPerf.csv`)
- Delta-V budget validation (`Delta-VBudget.csv`)
- Cost breakdown and total program cost estimates
- Launch vehicle comparison analysis
- Deployment timeline modeling
- Satellite bus design specifications
- Communications suite definition
- Latency analysis across all relay configurations
- GitHub Pages deployment of interactive visualization

## v0.2 (February 2026) — Lunar-First Reframe
- Reframed deployment strategy: Phase 0 lunar relay (~2029) before full heliocentric network
- 16 academic and institutional citations added
- Technical corrections to orbital mechanics and link budget assumptions
- Added technical audit document (`TINv0.2Audit`)
- Major README overhaul with quick specs table and project structure
- Supporting CSV datasets added to `data/`

## v0.1 (February 2026) — Initial Proposal
- Original proposal: conjunction-proof Earth-Mars comms via 5-6 heliocentric polar relay satellites
- Interactive 3D orbital visualization (`interplanetary_network_viz.html`)
- Core architecture: 3 polar heliocentric relays + 2-3 Sun-Earth Lagrange AI hubs
- MIT license
